-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 19, 2025 at 10:42 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopir`
--
CREATE DATABASE IF NOT EXISTS `shopir` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `shopir`;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_cat` int(4) NOT NULL,
  `sale_type` int(3) NOT NULL,
  `expire_discount` datetime NOT NULL,
  `name` varchar(100) NOT NULL,
  `image_product` varchar(100) NOT NULL,
  `rate` int(3) NOT NULL,
  `price` varchar(50) NOT NULL,
  `discount` tinyint(2) NOT NULL,
  `caption` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_cat`, `sale_type`, `expire_discount`, `name`, `image_product`, `rate`, `price`, `discount`, `caption`, `description`) VALUES
(1, 1, 1, '0000-00-00 00:00:00', 'هدفون بی سیم نیا مدل Q8 Ver3\r\n', 'p1.jpg', 3, '1,800,000 تومان', 10, 'توضیحات کوتاه', 'توضیحات بلند'),
(2, 1, 1, '0000-00-00 00:00:00', 'هدفون بی سیم نیا مدل Q8 Ver3\r\n', 'p1.jpg', 4, '1,800,000 تومان', 10, 'توضیحات کوتاه', 'توضیحات بلند'),
(3, 1, 1, '0000-00-00 00:00:00', 'هدست برای تماس\r\n', 'p3.jpg', 2, '600,000 تومان', 10, 'توضیحات کوتاه', 'توضیحات بلند'),
(4, 1, 1, '0000-00-00 00:00:00', 'هدست گیمینگ\r\n', 'p4.jpg', 5, '1,100,000 تومان', 10, 'توضیحات کوتاه', 'توضیحات بلند'),
(5, 1, 2, '0000-00-00 00:00:00', 'هدست ایسوس مدل strix 7.1', 'super-product.jpg', 0, '1,000,000 تومان\n', 60, 'توضیحات کوتاه', 'توضیحات بلند'),
(6, 2, 0, '0000-00-00 00:00:00', 'هدفون بی سیم نیا مدل Q8 Ver3', 'h11.jpg', 4, '1,400,000 تومان', 60, 'توضیحات کوتاه', 'توضیحات بلند'),
(7, 2, 0, '0000-00-00 00:00:00', 'هدفون بی سیم نیا مدل Q8 Ver3', 'h9.jpg', 0, '1,300,000 تومان', 60, 'توضیحات کوتاه', 'توضیحات بلند'),
(8, 2, 0, '0000-00-00 00:00:00', 'هدفون بی سیم نیا مدل Q8 Ver3', 'h10.jpg', 0, '1,250,000 تومان', 60, 'توضیحات کوتاه', 'توضیحات بلند'),
(9, 2, 0, '0000-00-00 00:00:00', 'هدفون بی سیم نیا مدل Q8 Ver3', 'h1.jpg', 3, '1,250,000 تومان', 60, 'توضیحات کوتاه', 'توضیحات بلند'),
(10, 2, 0, '0000-00-00 00:00:00', 'هدفون بی سیم نیا مدل Q8 Ver3', 'h2.jpg', 2, '1,250,000 تومان', 60, 'توضیحات کوتاه', 'توضیحات بلند'),
(11, 2, 0, '0000-00-00 00:00:00', 'هدفون بی سیم نیا مدل Q8 Ver3', 'h3.jpg', 1, '1,250,000 تومان', 60, 'توضیحات کوتاه', 'توضیحات بلند'),
(12, 2, 0, '0000-00-00 00:00:00', 'هدفون بی سیم نیا مدل Q8 Ver3', 'h5.jpg', 5, '1,250,000 تومان', 60, 'توضیحات کوتاه', 'توضیحات بلند'),
(13, 4, 0, '0000-00-00 00:00:00', 'هندز فری', 'h7.jpg', 3, '1,250,000 تومان', 60, 'توضیحات کوتاه', 'توضیحات بلند');

-- --------------------------------------------------------

--
-- Table structure for table `product_catgory`
--

DROP TABLE IF EXISTS `product_catgory`;
CREATE TABLE `product_catgory` (
  `catgory_id` int(9) NOT NULL,
  `cat_name` varchar(50) NOT NULL,
  `cat_description` varchar(255) NOT NULL,
  `cat_img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_catgory`
--

INSERT INTO `product_catgory` (`catgory_id`, `cat_name`, `cat_description`, `cat_img`) VALUES
(1, 'هدفون سیمی', 'فقط هدفون سیمی در این بخش موجود است.', 'cat1.jpg'),
(2, 'هدفون بی سیم', 'فقط هدفون بی سیم در این بخش موجود است.', 'cat2.jpg'),
(3, 'ایرپاد', 'فقط انواع ایرپادم در این بخش موجود است.', 'cat3.jpg'),
(4, 'هندزفری', 'فقط انواع هندزفری در این بخش موجود است.', 'cat4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `userz`
--

DROP TABLE IF EXISTS `userz`;
CREATE TABLE `userz` (
  `id` int(10) NOT NULL,
  `role` int(3) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `email` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userz`
--

INSERT INTO `userz` (`id`, `role`, `username`, `password`, `mobile`, `email`) VALUES
(1, 0, 'admin', 'd3812e0693d9a22242080a4a2da5b0b1', '09122050048', 'polbadman@gmail.com'),
(2, 1, 'Amir', '81dc9bdb52d04dc20036dbd8313ed055', '09053834702', 'info@amirmoghtader.ir'),
(3, 2, 'Amir', '1234', '09122050048', 'polbadman@yahoo.com'),
(4, 2, 'test', '098f6bcd4621d373cade4e832627b4f6', '09129999999', 'test@gmail.ir'),
(5, 2, 'test', '098f6bcd4621d373cade4e832627b4f6', '09125555555', 'sdfdsfs@fgfdgd.ol');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `product_catgory`
--
ALTER TABLE `product_catgory`
  ADD PRIMARY KEY (`catgory_id`);

--
-- Indexes for table `userz`
--
ALTER TABLE `userz`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `product_catgory`
--
ALTER TABLE `product_catgory`
  MODIFY `catgory_id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `userz`
--
ALTER TABLE `userz`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
